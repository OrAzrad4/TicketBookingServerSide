package com.hit.dao;
import java.util.List;
import com.hit.dm.Ticket;
import java.io.IOException;
import java.util.ArrayList;

public class TicketDaoImpl implements IDao<Long, Ticket> {

    public TicketDaoImpl() {

    }

    @Override
    public void delete(Ticket entity) throws IllegalArgumentException, IOException {

    }

    @Override
    public Ticket find(Long id) throws IllegalArgumentException, IOException {

        return null;
    }

    @Override
    public boolean save(Ticket entity) throws IllegalArgumentException, IOException {

        return false;
    }

    @Override
    public List<Ticket> findAll() throws IOException {

        return new ArrayList<>();
    }
}